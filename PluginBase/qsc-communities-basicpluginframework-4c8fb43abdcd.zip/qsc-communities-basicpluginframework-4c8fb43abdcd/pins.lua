table.insert(pins,{
  Name = "Audio Output",
  Direction = "output",
})