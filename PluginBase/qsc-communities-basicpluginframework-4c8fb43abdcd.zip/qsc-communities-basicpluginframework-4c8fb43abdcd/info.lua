PluginInfo = {
  Name = "Base Plugin",
  Version = "0.0",
  BuildVersion = "0.0.0.0",
  Id = "<guid>",
  Author = "Your_Company",
  Description = "A very basic plugin"  
}