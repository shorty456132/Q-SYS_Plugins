for ix,name in ipairs(PageNames) do
  table.insert(pages, {name = PageNames[ix]})
end