if props.plugin_show_debug.Value == false then 
  props["Debug Print"].IsHidden = true 
end